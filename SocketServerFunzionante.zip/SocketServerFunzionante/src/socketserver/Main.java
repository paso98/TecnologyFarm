
package socketserver;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
/**
 *
 * @author cattaneo_alex
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
        public static void main(String[] args) {
            		
	try {
            SocketServer s = new SocketServer();
            
            s.attendi();
            
            
            s.comunica();
	    String str = s.getDati();
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("file.csv", true)));
            
            out.println(str);
            
            
            out.flush();
            out.close(); 
            // apre il file in scrittura
	System.out.println("Inserito");        
	          
	} catch (IOException e) {
	         System.out.println(e);
	        } 
	
        System.out.println("Bye bye!");}
}

    

